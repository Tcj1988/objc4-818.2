//
// Test runner for all bounded_ptr tests.
//

#include <darwintest.h>

T_GLOBAL_META(
	T_META_NAMESPACE("bounded_ptr"),
	T_META_CHECK_LEAKS(false),
	T_META_RUN_CONCURRENTLY(true)
	);
