//
// Test runner for all bounded_array_ref tests.
//

#include <darwintest.h>

T_GLOBAL_META(
	T_META_NAMESPACE("bounded_array_ref"),
	T_META_CHECK_LEAKS(false),
	T_META_RUN_CONCURRENTLY(true)
	);
