//
// Test runner for all bounded_array tests.
//

#include <darwintest.h>

T_GLOBAL_META(
	T_META_NAMESPACE("bounded_array"),
	T_META_CHECK_LEAKS(false),
	T_META_RUN_CONCURRENTLY(true)
	);
